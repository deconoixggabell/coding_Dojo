let age = 10
let height = 42

if(age >= 10 , height >= 42){
    console.log("Enjoy the ride")
}
else if (age < 10, height < 42)
    console.log("Sorry you cant get on the ride")