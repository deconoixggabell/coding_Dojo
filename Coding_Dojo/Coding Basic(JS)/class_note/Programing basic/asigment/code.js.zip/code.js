// The Variable likeCount will be define as equal to zero
var likeCount = 0;
// in the next bock of code we will be creating a function witch will be call "increaseLikes"
function increaseLikes() {
    // in this portion of the code likeCount is added by one
    likeCount = likeCount + 1;
}
