//in the next block of code we will set the value to variable age and height
let age = 10
let height = 42

/*
In order to get on the ride the condition on the next block of code must be met.
both condition
*/
if(age >= 10 && height >= 42){
    console.log("Get on that ride, Kiddo!")
}

// If the kid doeat meet the requerment than this next block of code will run.
else {
    console.log("sorry kiddo. Maybe next year!")
}